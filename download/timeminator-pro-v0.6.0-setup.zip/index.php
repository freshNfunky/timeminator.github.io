<?php
declare(strict_types=1);

/**
 * FTP-to-web bootstrap, shipped as `index.php` next to the release ZIP.
 *
 * Upload this file *as* index.php together with the release ZIP into an
 * EMPTY target folder, then just open the site in a browser - no separate
 * filename to remember or type. On confirm, it extracts the ZIP (every file
 * except the app's own index.php), then atomically replaces itself with the
 * app's real index.php via rename() and redirects, so the very next request
 * runs the real app - which itself finds no config.php yet and sends you on
 * to install.php. Not part of the app itself; it deletes the ZIP and, via
 * the rename, effectively deletes itself on success.
 *
 * Why rename() and not just overwrite in place: PHP has already fully read
 * and compiled this script before this code runs, so replacing the file on
 * disk mid-request never affects the current request - but truncate-in-place
 * writes risk a half-written file if anything goes wrong mid-write, and can
 * be served stale by some opcache configurations. rename() swaps the
 * directory entry atomically instead, so an interrupted run always leaves
 * either the old bootstrap or the complete new file in place, never a
 * half-written index.php - the safe failure mode for something people run
 * exactly once, unattended, over FTP+browser.
 *
 * Needs the ZipArchive PHP extension (near-universal on shared hosting).
 */

if (!class_exists('ZipArchive')) {
    exit('PHP-Erweiterung ZipArchive fehlt. Bitte das ZIP stattdessen ueber die Dateiverwaltung deines Hosters entpacken.');
}

// Guard: refuse if a real install already looks present, so a second visit
// (or someone else finding the URL) can never overwrite a finished install.
foreach (['install.php', 'config.php', 'src'] as $f) {
    if (file_exists(__DIR__ . '/' . $f)) {
        exit("Hier liegt schon eine Timeminator-Installation ($f gefunden). Zum Schutz vor Ueberschreiben wird nichts entpackt.");
    }
}

$zips = glob(__DIR__ . '/*.zip') ?: [];
if (count($zips) === 0) {
    exit('Kein ZIP in diesem Ordner gefunden. Lade die Release-ZIP-Datei zusammen mit dieser index.php per FTP hoch.');
}
if (count($zips) > 1) {
    exit('Mehr als ein ZIP in diesem Ordner gefunden: ' . implode(', ', array_map('basename', $zips)) . '. Bitte nur die gewuenschte Datei liegen lassen.');
}
$zipPath = $zips[0];

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    ?>
    <!doctype html><html lang="de"><head><meta charset="utf-8"><title>Timeminator entpacken</title></head>
    <body style="font:15px/1.5 -apple-system,sans-serif;max-width:520px;margin:60px auto;padding:0 16px">
    <h1>Timeminator entpacken</h1>
    <p>Gefunden: <code><?= h(basename($zipPath)) ?></code> (<?= h(number_format(filesize($zipPath) / 1024 / 1024, 1)) ?> MB)</p>
    <p>Entpackt den Inhalt in diesen Ordner und leitet danach direkt zur Installation weiter.</p>
    <form method="post"><button type="submit" style="font-size:15px;padding:10px 18px">Jetzt entpacken</button></form>
    </body></html>
    <?php
    exit;
}

$zip = new ZipArchive();
if ($zip->open($zipPath) !== true) {
    exit('ZIP konnte nicht geoeffnet werden (beschaedigter Upload? Im Binaermodus per FTP neu hochladen).');
}

// Release ZIPs wrap everything in one top-level folder (e.g. timeminator-v1.2.3/);
// find and strip it so files land directly in this directory.
$prefix = '';
if ($zip->numFiles > 0) {
    $first = $zip->getNameIndex(0);
    if ($first !== false && str_contains($first, '/')) {
        $prefix = explode('/', $first, 2)[0] . '/';
    }
}

$indexContent = null;
$written = 0;
for ($i = 0; $i < $zip->numFiles; $i++) {
    $name = $zip->getNameIndex($i);
    if ($name === false) {
        continue;
    }
    $rel = $prefix !== '' && str_starts_with($name, $prefix) ? substr($name, strlen($prefix)) : $name;
    $rel = ltrim($rel, '/');
    if ($rel === '' || str_contains($rel, '..')) {
        continue; // the wrapper dir entry itself, or path traversal - skip
    }
    if (str_ends_with($name, '/')) {
        @mkdir(__DIR__ . '/' . $rel, 0775, true);
        continue;
    }
    if ($rel === 'index.php') {
        // Held back and written last (see rename() below) so a half-finished
        // extraction never looks like a complete, ready-to-serve install.
        $indexContent = $zip->getFromIndex($i);
        continue;
    }
    $target = __DIR__ . '/' . $rel;
    @mkdir(dirname($target), 0775, true);
    $content = $zip->getFromIndex($i);
    if ($content === false || file_put_contents($target, $content) === false) {
        $zip->close();
        exit("Fehler beim Schreiben von $rel - Abbruch. Rechte im Zielordner pruefen und die Seite erneut aufrufen (bereits geschriebene Dateien bleiben liegen, index.php wird erst am Ende ersetzt).");
    }
    $written++;
}
$zip->close();

if ($indexContent === null) {
    exit('ZIP enthaelt keine index.php - Abbruch. Bitte ein anderes/vollstaendiges Release-ZIP verwenden.');
}

$tmp = __DIR__ . '/.index.php.new';
if (file_put_contents($tmp, $indexContent) === false || !rename($tmp, __DIR__ . '/index.php')) {
    exit('Konnte die echte index.php nicht einsetzen (Schreibrechte pruefen). Alle anderen Dateien sind bereits entpackt; Seite erneut aufrufen, sobald die Rechte stimmen.');
}
@unlink($zipPath);

header('Location: .');
echo '<!doctype html><meta charset="utf-8"><p>' . ($written + 1) . ' Dateien entpackt. Weiter zur <a href="./">Installation</a>.</p>';
